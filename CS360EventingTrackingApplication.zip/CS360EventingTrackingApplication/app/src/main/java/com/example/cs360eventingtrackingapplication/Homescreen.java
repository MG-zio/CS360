package com.example.cs360eventingtrackingapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class Homescreen extends AppCompatActivity implements EventAdapter.OnEventClickListener {

    private EventAdapter adapter;
    private EventDbHelper dbHelper;
    private RecyclerView grid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //EdgeToEdge.enable(this);
        setContentView(R.layout.activity_homescreen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0);
            return insets;
        });

        dbHelper = new EventDbHelper(this);
        FloatingActionButton addEvent = findViewById(R.id.fab_add);
        ImageButton settingsButton = findViewById(R.id.settingsButton);
        grid = findViewById(R.id.eventGrid);
        adapter = new EventAdapter(this);

        grid.setLayoutManager(new GridLayoutManager(this, 2));
        grid.setAdapter(adapter);

        // Add event floating button
        addEvent.setOnClickListener(view ->{
            Intent intent = new Intent(Homescreen.this, EventCreator.class);
            startActivity(intent);
        });

        // Settings button
        settingsButton.setOnClickListener(view ->{
            Intent intent = new Intent(Homescreen.this, Settings.class);
            startActivity(intent);
        });

        loadEvents();
    }

    private void loadEvents(){
        List<Event> events = dbHelper.getAllEvents();
        adapter.updateEvents(events);
    }


    @Override
    protected void onResume(){
        super.onResume();
        loadEvents();
    }

    @Override
    public void onEventClick(Event event){
        Intent intent = new Intent(Homescreen.this, EventCreator.class);
        intent.putExtra("is_editing", true);
        intent.putExtra("event_id", event.getId());
        startActivity(intent);
    }
}