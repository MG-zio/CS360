package com.example.cs360eventingtrackingapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.widget.Toast;

public class EventAlarmReciever extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String eventTitle = intent.getStringExtra("event_title");
        String eventTime = intent.getStringExtra("event_time");
        String phoneNumber = intent.getStringExtra("phone_number");

        if (eventTitle == null || eventTime == null){
            return;
        }

        String message = "Reminder: " + eventTitle + " at " + eventTime;

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(context, "Reminder sent to " + phoneNumber, Toast.LENGTH_SHORT).show();

        }
        catch (Exception e){
            Toast.makeText(context, "Failed to send reminder.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

        }

}
