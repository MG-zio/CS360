package com.example.cs360eventingtrackingapplication;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import android.os.Build;

public class EventDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "events.db";
    private static final int DATABASE_VERSION = 2;

    public EventDbHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        String SQL_CREATE_EVENTS_TABLE = "CREATE TABLE " + EventContract.EventEntry.TABLE_NAME + " (" +
                EventContract.EventEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                EventContract.EventEntry.COLUMN_TITLE + " TEXT NOT NULL," +
                EventContract.EventEntry.COLUMN_DATE + " TEXT NOT NULL," +
                EventContract.EventEntry.COLUMN_TIME + " TEXT NOT NULL," +
                EventContract.EventEntry.COLUMN_DESCRIPTION + " TEXT);";
        db.execSQL(SQL_CREATE_EVENTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + EventContract.EventEntry.TABLE_NAME);
        onCreate(db);
    }


    /**
     * Insert event into database
     * @param event Event to insert
     * @return ID of inserted event
     */
    public long insertEvent(Event event){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EventContract.EventEntry.COLUMN_TITLE, event.getTitle());
        values.put(EventContract.EventEntry.COLUMN_DATE, event.getDate());
        values.put(EventContract.EventEntry.COLUMN_TIME, event.getTime());
        values.put(EventContract.EventEntry.COLUMN_DESCRIPTION, event.getDescription());

        long id = db.insert(EventContract.EventEntry.TABLE_NAME, null, values);
        event.setId(id);
        db.close();
        return id;
    }

    /**
     * Get all events from database
     * @return List of events
     */
    public List<Event> getAllEvents(){
        List<Event> events = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String[] projection = {
                EventContract.EventEntry._ID,
                EventContract.EventEntry.COLUMN_TITLE,
                EventContract.EventEntry.COLUMN_DATE,
                EventContract.EventEntry.COLUMN_TIME,
                EventContract.EventEntry.COLUMN_DESCRIPTION
        };

        Cursor cursor = db.query(
                EventContract.EventEntry.TABLE_NAME,
                projection,
                null, null, null, null,
                EventContract.EventEntry.COLUMN_DATE + " ASC, " +
                        EventContract.EventEntry.COLUMN_TIME + " ASC"
        );

        if (cursor.moveToFirst()){
            do{
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(EventContract.EventEntry._ID));
                String title = cursor.getString(cursor.getColumnIndexOrThrow(EventContract.EventEntry.COLUMN_TITLE));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(EventContract.EventEntry.COLUMN_DATE));
                String time = cursor.getString(cursor.getColumnIndexOrThrow(EventContract.EventEntry.COLUMN_TIME));
                String description = cursor.getString(cursor.getColumnIndexOrThrow(EventContract.EventEntry.COLUMN_DESCRIPTION));

                events.add(new Event(id, title, date, time, description));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return events;
    }

    /**
     * Update event in database
     * @param event Event to update
     * @return Number of rows updated
     */
    public int updateEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EventContract.EventEntry.COLUMN_TITLE, event.getTitle());
        values.put(EventContract.EventEntry.COLUMN_DATE, event.getDate());
        values.put(EventContract.EventEntry.COLUMN_TIME, event.getTime());
        values.put(EventContract.EventEntry.COLUMN_DESCRIPTION, event.getDescription());

        int rowsAffected = db.update(
                EventContract.EventEntry.TABLE_NAME,
                values,
                EventContract.EventEntry._ID + " = ?",
                new String[]{String.valueOf(event.getId())}
        );
        db.close();
        return rowsAffected;
    }

    /**
     * Delete event from database
     * @param id ID of event to delete
     */
    public void deleteEvent(long id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(
                EventContract.EventEntry.TABLE_NAME,
                EventContract.EventEntry._ID + " = ?",
                new String[]{String.valueOf(id)}
        );
        db.close();
    }

    /**
     * Get event by ID from database
     * @param id ID of event to get
     * @return Event with given ID
     */
    public Event getEventById(long id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                EventContract.EventEntry.TABLE_NAME,
                null,
                EventContract.EventEntry._ID + " = ?",
                new String[]{String.valueOf(id)},
                null, null, null
        );

        if (cursor != null && cursor.moveToFirst()){
            String title = cursor.getString(cursor.getColumnIndexOrThrow(EventContract.EventEntry.COLUMN_TITLE));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(EventContract.EventEntry.COLUMN_DATE));
            String time = cursor.getString(cursor.getColumnIndexOrThrow(EventContract.EventEntry.COLUMN_TIME));
            String description = cursor.getString(cursor.getColumnIndexOrThrow(EventContract.EventEntry.COLUMN_DESCRIPTION));

            cursor.close();
            db.close();
            return new Event(id, title, date, time, description);
        }
        if (cursor != null){
            cursor.close();
        }
        db.close();
        return null;
    }

    /**
     * Schedule event reminder
     * @param event Event to schedule
     * @param phoneNumber Phone number to send reminder to
     * @param context Context of application
      */
    public void scheduleEventReminder(Event event, String phoneNumber, Context context){
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
            String dateTime = event.getDate() + " " + event.getTime();

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(sdf.parse(dateTime));

            if (calendar.getTimeInMillis() < System.currentTimeMillis()){
                return;
            };

            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarmManager == null){
                return;
            }

            // Check if exact alarms are allowed
            if (!alarmManager.canScheduleExactAlarms()) {
                android.widget.Toast.makeText(context,
                        "Please allow exact alarms in Settings for reminders to work.",
                        android.widget.Toast.LENGTH_LONG).show();
            }


            Intent intent = new Intent(context, EventAlarmReciever.class);
            intent.setAction("com.example.cs360eventingtrackingapplication.EVENT_ALARM");
            intent.putExtra("event_title", event.getTitle());
            intent.putExtra("event_time", dateTime);
            intent.putExtra("phone_number", phoneNumber);

            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    context,
                    (int) event.getId(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // Set alarm for event
            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    pendingIntent
            );

        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Cancel event reminder
     * @param eventId ID of event to cancel
     * @param context Context of application
     */
    public void cancelEventReminder(long eventId, Context context){
        Intent intent = new Intent(context, EventAlarmReciever.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                (int) eventId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null){
            alarmManager.cancel(pendingIntent);
        }
    }
}