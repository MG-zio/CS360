package com.example.cs360eventingtrackingapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDbHelper  extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "users.db";
    private static final int DATABASE_VERSION = 1;

    public UserDbHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        String SQL_CREATE_USERS_TABLE = "CREATE TABLE " + UserContract.UserEntry.TABLE_NAME + " (" +
                UserContract.UserEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                UserContract.UserEntry.COLUMN_USERNAME + " TEXT NOT NULL," +
                UserContract.UserEntry.COLUMN_PASSWORD + " TEXT NOT NULL);";
        db.execSQL(SQL_CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + UserContract.UserEntry.TABLE_NAME);
        onCreate(db);
    }

    /**
    * Register a new user
    * @param username Username of user
    * @param password Password of user
    * @return True if user was successfully registered, false otherwise
    * */
    public boolean registerUser(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserContract.UserEntry.COLUMN_USERNAME, username);
        values.put(UserContract.UserEntry.COLUMN_PASSWORD, password);

        try {
            long id = db.insertOrThrow(UserContract.UserEntry.TABLE_NAME, null, values);
            // Username successfully added to database
            return id != -1;
        } catch (Exception e){
            // Username already exists in database
            return false;
        } finally {
            // Close db regardless of success or failure
            db.close();
        }
    }

    /**
     * Check if user exists in database
     * @param username Username of user
     * @param password Password of user
     * @return True if user exists, false otherwise
     * */
    public boolean checkLogin(String username, String password){
        SQLiteDatabase db = this.getReadableDatabase();

        // Check if username and password exist in database
        String[] projection = {UserContract.UserEntry._ID};
        String selection = UserContract.UserEntry.COLUMN_USERNAME + " = ? AND " +
                UserContract.UserEntry.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(
                UserContract.UserEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null, null, null
        );

        // Check if any rows were returned
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    /**
     * Check if username is already taken
     * @param username Username of user
     * @return True if username is already taken, false otherwise
     * */
    public boolean isUsernameTaken(String username){
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                UserContract.UserEntry.TABLE_NAME,
                new String[]{UserContract.UserEntry._ID},
                UserContract.UserEntry.COLUMN_USERNAME + " = ?",
                new String[]{username},
                null, null, null
        );

        // Check if any rows were returned
        boolean taken = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return taken;

    }
}
