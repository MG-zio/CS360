package com.example.cs360eventingtrackingapplication;

import android.provider.BaseColumns;

public final class EventContract {
    private EventContract() {}

    public static class EventEntry implements BaseColumns {
        public static final String TABLE_NAME = "events";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_DATE = "date";
        public static final String COLUMN_TIME = "time";
        public static final String COLUMN_DESCRIPTION = "description";
    }
}
