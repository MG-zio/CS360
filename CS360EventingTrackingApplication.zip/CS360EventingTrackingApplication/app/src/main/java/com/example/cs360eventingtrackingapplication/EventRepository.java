package com.example.cs360eventingtrackingapplication;

import java.util.ArrayList;

public class EventRepository {
    // defunct
    public static ArrayList<Event> eventList = new ArrayList<>();
}
