package com.example.cs360eventingtrackingapplication;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;


public class EventCreator extends AppCompatActivity {
    EditText title, date, time, description;
    Button deleteEvent, createEvent;
    private boolean isEditing = false;
    private long  editingEventId = -1; //default
    private EventDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //EdgeToEdge.enable(this);
        setContentView(R.layout.activity_event_creator);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new EventDbHelper(this);

        title = findViewById(R.id.eventTitle);
        date = findViewById(R.id.eventDate);
        time = findViewById(R.id.eventTime);
        description = findViewById(R.id.eventDescription);

        deleteEvent = findViewById((R.id.eventDelete));
        createEvent = findViewById(R.id.eventCreate);

        isEditing = getIntent().getBooleanExtra("is_editing", false);
        editingEventId = getIntent().getLongExtra("event_id", -1);

        if (isEditing){
            deleteEvent.setText("Delete");
        }

        // If editing, load event data
        if (isEditing && editingEventId != -1){
            loadEventForEditing();
            createEvent.setText("Save Changes");
        }

        date.setFocusable(false);
        date.setClickable(true);
        date.setInputType(android.text.InputType.TYPE_NULL);
        date.setOnClickListener(v ->{
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(EventCreator.this,
                    (view, year1, monthOfYear, dayOfMonth) ->
                            date.setText(year1 + "-" + String.format("%02d", monthOfYear + 1) + "-" + String.format("%02d", dayOfMonth)),
                    year, month, day);
            datePickerDialog.show();
        });


        time.setFocusable(false);
        time.setClickable(true);
        time.setInputType(android.text.InputType.TYPE_NULL);
        time.setOnClickListener(v ->{
            final Calendar t = Calendar.getInstance();
            int hour = t.get(Calendar.HOUR_OF_DAY);
            int minute = t.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    (view, hourOfDay, minute1) -> {
                        String selectedTime = String.format("%02d:%02d", hourOfDay, minute1);
                        time.setText(selectedTime);
                    }, hour, minute, false);
            timePickerDialog.show();
        });

        deleteEvent.setOnClickListener(v ->{
            deleteCurrentEvent();
        });

        createEvent.setOnClickListener(v ->{
            saveEvent();
        });
    }


    private void loadEventForEditing(){
        Event event = dbHelper.getEventById(editingEventId);
        if (event == null){
            Toast.makeText(this, "Event not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        else{
            title.setText(event.getTitle());
            date.setText(event.getDate());
            time.setText(event.getTime());
            description.setText(event.getDescription());
        }
    }

    private void saveEvent(){
        String svTitle = title.getText().toString().trim();
        String svDate = date.getText().toString().trim();
        String svTime = time.getText().toString().trim();
        String svDescription = description.getText().toString().trim();

        if (svTitle.isEmpty() || svDate.isEmpty() || svTime.isEmpty()){
            Toast.makeText(this, "Title, Date, and Time required.", Toast.LENGTH_SHORT).show();
            return;
        }

        String phoneNumber = "1234567890";

        if (isEditing){
            Event event = new Event(editingEventId, svTitle, svDate, svTime, svDescription);
            int rowsUpdated = dbHelper.updateEvent(event);

            if (rowsUpdated > 0) {
                dbHelper.cancelEventReminder(editingEventId, this);
                dbHelper.scheduleEventReminder(event, phoneNumber, this);
                Toast.makeText(this, "Event updated successfully.", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(this, "Failed to update event.", Toast.LENGTH_SHORT).show();
            }
        }
        else{
            // Create new event
            Event newEvent = new Event(0, svTitle, svDate, svTime, svDescription);
            long newId = dbHelper.insertEvent(newEvent);

            if (newId != -1){
                dbHelper.scheduleEventReminder(newEvent, phoneNumber, this);
                Toast.makeText(this, "Event created successfully.", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(this, "Failed to create event.", Toast.LENGTH_SHORT).show();
            }
        }
        finish();
    }

    private void deleteCurrentEvent(){
        if (editingEventId != -1){
            dbHelper.cancelEventReminder(editingEventId, this);
            dbHelper.deleteEvent(editingEventId);
            Toast.makeText(this, "Event deleted successfully.", Toast.LENGTH_SHORT).show();
        }
        finish();
    }
}