package com.example.cs360eventingtrackingapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginScreen extends AppCompatActivity {

    EditText loginUsername;
    EditText loginPassword;
    Button loginButton;
    Button createAccountButton;
    private UserDbHelper userDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userDbHelper = new UserDbHelper(this);

        loginUsername = findViewById(R.id.loginUsername);
        loginPassword = findViewById(R.id.loginPassword);

        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.loginCreateAccountButton);

        // Login button on click logic
        loginButton.setOnClickListener(view ->{
            String username = loginUsername.getText().toString();
            String password = loginPassword.getText().toString();

            if (username.isEmpty() || password.isEmpty()){
                Toast.makeText(this, "Please enter username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (userDbHelper.checkLogin(username, password)){
                Toast.makeText(this, "Login Successful.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginScreen.this, Homescreen.class);
                startActivity(intent);
            }
            else{
                Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
            }
        });

        // Create account button on click logic
        createAccountButton.setOnClickListener(view ->{
            String username = loginUsername.getText().toString();
            String password = loginPassword.getText().toString();

            if (username.isEmpty() || password.isEmpty()){
                Toast.makeText(this, "Please enter username and password.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (userDbHelper.isUsernameTaken(username)){
                Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show();
            }
            else{
                boolean success = userDbHelper.registerUser(username, password);
                if (success){
                    Toast.makeText(this, "Account created successfully.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginScreen.this, Homescreen.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(this, "Failed to create account.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}